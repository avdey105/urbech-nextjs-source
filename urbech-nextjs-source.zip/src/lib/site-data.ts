import siteDataJson from "@/data/site-data.json";

export type SiteLink = {
  label: string;
  href: string;
};

export type ContactInfo = {
  phones: string[];
  email: string;
  address: string;
  workingHours: string;
  coordinates: {
    lat: number;
    lng: number;
  } | null;
};

export type HeroSlide = {
  image: string;
  alt: string;
};

export type CategoryRecord = {
  slug: string;
  title: string;
  href: string;
  excerpt: string;
  productSlugs: string[];
  products: string[];
  heroImage: string | null;
};

export type ProductRecord = {
  slug: string;
  title: string;
  href: string;
  article: string;
  priceText: string;
  availability: string;
  mainImage: string | null;
  gallery: string[];
  summary: string;
  descriptionHtml: string;
  categoryNames: string[];
  categorySlug: string;
  relatedSlugs: string[];
};

export type InfoPageRecord = {
  slug: string;
  title: string;
  href: string;
  excerpt: string;
  bodyHtml: string;
  contacts?: ContactInfo;
};

export type SiteData = {
  generatedAt: string;
  brand: {
    name: string;
    title: string;
    description: string;
    slogan: string;
    logoImage: string | null;
  };
  navigation: {
    top: SiteLink[];
    categories: SiteLink[];
  };
  heroSlides: HeroSlide[];
  contact: ContactInfo;
  categories: CategoryRecord[];
  products: ProductRecord[];
  pages: InfoPageRecord[];
};

export const siteData = siteDataJson as SiteData;
export const topNavigation = siteData.navigation.top;
export const categoryNavigation = siteData.navigation.categories;
export const categories = siteData.categories;
export const products = siteData.products;
export const infoPages = siteData.pages;

export function getCategoryBySlug(slug: string) {
  return categories.find((category) => category.slug === slug);
}

export function getProductBySlug(slug: string) {
  return products.find((product) => product.slug === slug);
}

export function getProductsByCategorySlug(slug: string) {
  return products.filter((product) => product.categorySlug === slug);
}

export function getInfoPageBySlug(slug: string) {
  return infoPages.find((page) => page.slug === slug);
}

export function getRelatedProducts(product: ProductRecord) {
  const directProducts = product.relatedSlugs
    .map((slug) => getProductBySlug(slug))
    .filter((value): value is ProductRecord => Boolean(value));

  const fallbackProducts = products.filter(
    (item) =>
      item.slug !== product.slug &&
      item.categorySlug === product.categorySlug &&
      !directProducts.some((relatedProduct) => relatedProduct.slug === item.slug),
  );

  const extraProducts = products.filter(
    (item) =>
      item.slug !== product.slug &&
      item.categorySlug !== product.categorySlug &&
      !directProducts.some((relatedProduct) => relatedProduct.slug === item.slug),
  );

  return [...directProducts, ...fallbackProducts, ...extraProducts].slice(0, 4);
}
