import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function createPhoneHref(phone: string) {
  return `tel:${phone.replace(/[^\d+]/g, "")}`;
}

export function hasNumericPrice(priceText: string) {
  const numeric = Number(priceText.replace(/[^\d.,]/g, "").replace(",", "."));
  return Number.isFinite(numeric) && numeric > 0;
}

export function extractNumericPrice(priceText: string) {
  const numeric = Number(priceText.replace(/[^\d.,]/g, "").replace(",", "."));
  return Number.isFinite(numeric) ? numeric : null;
}

export function formatCurrency(priceText: string) {
  const price = extractNumericPrice(priceText);

  if (price === null || price <= 0) {
    return priceText;
  }

  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB",
    maximumFractionDigits: 0,
  }).format(price);
}

export function cleanProductSummary(summary: string) {
  return summary.replace(/^Описание\s+/i, "").trim();
}

export function cleanLegacyContentHtml(html: string) {
  return html
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<svg[\s\S]*?<\/svg>/gi, "")
    .replace(/<smart-captcha[\s\S]*?<\/smart-captcha>/gi, "")
    .replace(/<div[^>]*class="[^"]*lpc-form[^"]*"[\s\S]*$/i, "")
    .replace(/<div[^>]*class="[^"]*localmap[^"]*"[\s\S]*$/i, "")
    .replace(/<div[^>]*class="[^"]*comments_block[^"]*"[\s\S]*$/i, "")
    .replace(/<form[\s\S]*?<\/form>/gi, "")
    .replace(/<iframe[\s\S]*?<\/iframe>/gi, "")
    .replace(/<a\b[^>]*class="[^"]*highslide[^"]*"[^>]*>[\s\S]*?<\/a>/gi, "")
    .replace(/<img\b[^>]*>/gi, "")
    .replace(/\sstyle="[^"]*"/gi, "")
    .replace(/\son[a-z]+="[^"]*"/gi, "")
    .replace(/&nbsp;/g, " ")
    .trim();
}

export function extractProductDescriptionHtml(html: string) {
  const descriptionMatch = html.match(/<div[^>]*class="[^"]*desc-area\s+html_block[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
  return cleanLegacyContentHtml(descriptionMatch?.[1] ?? html);
}
