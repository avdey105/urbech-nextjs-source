"use client";

import { Minus, Plus, ShoppingBag } from "lucide-react";

import { cn } from "@/lib/utils";
import { useCartStore } from "@/store/cart-store";

type AddToCartButtonProps = {
  productSlug: string;
  className?: string;
  compact?: boolean;
};

export function AddToCartButton({ productSlug, className, compact = false }: AddToCartButtonProps) {
  const addItem = useCartStore((state) => state.addItem);
  const decrementItem = useCartStore((state) => state.decrementItem);
  const quantity = useCartStore((state) => state.items[productSlug] ?? 0);

  function handleClick() {
    addItem(productSlug);
  }

  if (quantity > 0) {
    return (
      <div
        className={cn(
          "inline-flex items-center justify-between gap-1 rounded-full bg-[var(--color-primary-deep)] p-1 text-white shadow-[0_12px_26px_rgba(23,85,79,0.18)]",
          compact ? "h-9 min-w-0 text-xs sm:h-11 sm:min-w-32 sm:text-sm" : "h-11 min-w-40 text-sm",
          className,
        )}
      >
        <button
          aria-label="Уменьшить количество"
          className="inline-flex h-7 w-7 items-center justify-center rounded-full transition hover:bg-white/14 sm:h-9 sm:w-9"
          onClick={() => decrementItem(productSlug)}
          type="button"
        >
          <Minus className="h-4 w-4" />
        </button>
        <span className="min-w-6 text-center font-semibold sm:min-w-8">{quantity}</span>
        <button
          aria-label="Увеличить количество"
          className="inline-flex h-7 w-7 items-center justify-center rounded-full transition hover:bg-white/14 sm:h-9 sm:w-9"
          onClick={handleClick}
          type="button"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    );
  }

  return (
    <button
      className={cn(
        "inline-flex items-center justify-center rounded-full font-semibold transition",
        "bg-[var(--color-accent)] text-white hover:bg-[var(--color-accent-strong)]",
        compact ? "h-9 min-w-0 gap-1.5 px-2 text-xs sm:h-11 sm:min-w-32 sm:gap-2 sm:px-5 sm:text-sm" : "h-11 min-w-40 gap-2 px-5 text-sm",
        className,
      )}
      onClick={handleClick}
      type="button"
    >
      <ShoppingBag className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
      В корзину
    </button>
  );
}
